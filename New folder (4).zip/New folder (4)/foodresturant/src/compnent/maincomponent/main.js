import './main.css';
import React from 'react';
import { Link } from 'react-router-dom';


function Main(){
    return(<>
    <div className='container main_text'>
      <h1>Welcom to Food's Kitchen</h1>
<br/>
<Link to="/gotomenu"><a className='anchor_style' >GO TO MENU</a></Link>
      </div>
    </>)
}
export default Main;