import './login.css';
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


function Login() {
    const navigate = useNavigate();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState()
    const [output ,setOutput]=useState();

    const handleLogin = () => {

        var obj = { "email": email, "password": password };
        axios.post("http://127.0.0.1:3001/user/login", obj).then((res) => {
            if(obj.email == undefined || obj.email == ""){
                alert('This field is required');
                document.getElementById("email").focus();
              }
            var data = res.data.userDetails;
            localStorage.setItem("name", data.name);
            localStorage.setItem("email", data.email);
            localStorage.setItem("role", data.role);
            localStorage.setItem("token", res.data.token);
            localStorage.setItem("mobile", data.mobile);
            navigate("/main");
        }).catch(() => {
          

        });
    };
  

    return (
        <>
<br/><br/>

            <center>   <h1>Login Page</h1></center>
            <div style={{ color: "blue", fontSize: "40px", alignContent: "center", textAlign: "center" }}>

            </div>
            <div class="container ">

                <div class="shadow p-3 mb-5 bg-body-tertiary rounded">
                    <form class="was-validated" >



                        <div class="form-outline mb-4">
                            <label class="form-label" for="form6Example5" required>Email</label>
                            <input type="email" id="email" class="form-control" required name="email" value={email} onChange={e => setEmail(e.target.value)} />

                        </div>
                        <div class="form-outline mb-4">
                            <label class="form-label" for="form6Example4" required>Password</label>
                            <input type="password" class="form-control" name="password" value={password} onChange={e => setPassword(e.target.value)} />

                        </div>




                        <input type="button" class="btn btn-primary btn-block mb-4" value="Login" onClick={handleLogin} />
                    </form>
                </div>
            </div>


        </>

    );
}

export default Login;
