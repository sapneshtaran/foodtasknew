import './Register.css';
import React from 'react';
import {useState} from 'react';
import axios from 'axios';
import { _userapiurl } from '../../Api.url';

function Register(){
  const [name,setName]=useState();
  const [email,setEmail]=useState();
  const [password,setPassword]=useState();
  const[mobile,setMobile]=useState();
  const[address,setAddress]=useState();
  const [city,setCity]=useState();
  const [gender,setGender]=useState();

  
  const handleForm=()=>{

    
    var userDetails={"name":name,"email":email,"password":password,"mobile":mobile,"address":address,"city":city,"gender":gender};
     axios.post(_userapiurl+"save",userDetails).then(()=>{
      
      alert("User registerd successfully");
      setName("");
      setEmail("");
      setPassword("");
       setMobile("");
      setAddress("");
      setCity("");
      setGender("");
       document.getElementsByClassName('text-danger').innerText='';

    }).catch((error)=>{
     
      if(userDetails.name == undefined || userDetails.name == ""){
        document.getElementById('name').innerText='This field is required';
      }
      else if(userDetails.name.length <= 2) {
        document.getElementById('name').innerText='Name should be grater then 2 character.';
      }else{
        document.getElementById('name').innerText='';
      }
//------------------------------------------------------------------------//
      // Email validation
      
      const validateEmail = (email) => {
        return email.match(
          /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
      };

      if(userDetails.email == undefined || userDetails.email == ""){
        document.getElementById('email').innerText='This field is required';
      }
      else if(validateEmail(userDetails.email)) {
        document.getElementById('email').innerText='';
      }else{
        document.getElementById('email').innerText='Please enter valid email address.';
      }
//----------------------------------------------------//
 //password validation
    const validatePassword = (password)=>{
      return password.match(
        "^(?=.[A-Za-z])(?=.\d)[A-Za-z\d]{8,}$"
      );
   };

   if(userDetails.password == undefined || userDetails.password == ""){
    document.getElementById('password').innerText='This field is required';
  }
  else if(validatePassword(userDetails.password)) {
    document.getElementById('password').innerText='';
  }else{
    document.getElementById('password').innerText='please enter minimum eight characters, at least one letter and one number';
  }

  //-----------------------------------------------//
   //mobile validation
     if(userDetails.mobile == undefined || userDetails.mobile == ""){
      document.getElementById('mobile').innerText='This field is required';
      }
       else if(userDetails.mobile.length == 10) {
         document.getElementById('mobile').innerText='';
        } else{
          document.getElementById('mobile').innerText='Please enter 10 digits mobile no.';
       }
//--------------------------------------------//
//Address validation
if(userDetails.address== undefined || userDetails.address== ""){
  document.getElementById('address').innerText='This filed is required';
}
else{
document.getElementById('address').innerText='';
}
//-------------------------------------------------//
//city validation
             if(userDetails.city == undefined || userDetails.city == ""){
                     document.getElementById('city').innerText='This filed is required';
                }
                  else{
                  document.getElementById('city').innerText='';
              }

//---------------------------------------------//
//gender validation      
             if(userDetails.gender == undefined || userDetails.gender == ""){
                 document.getElementById('gender').innerText='This filed is required';
              }
           else{
                document.getElementById('gender').innerText='';
            }        

     });
       
    
  };
       
  
  return(
   <>
         {/* (about)Home section */}

  <section class="about_section layout_padding">
    <div class="container  ">
      <div class="row">
        <div class="col-md-12">
          <div class="detail-box">
          
            <h1>Register Here!</h1>
            <br/>
            <form >
            <div class="form-group">
            <label for="name">Enter Name:</label>
           <input type="text" class="form-control" value={name} onChange={e=>setName(e.target.value)}/>
             <span class="text-danger" id="name"></span>
           </div>
           <div class="form-group">
            <label for="email">Email address:</label>
            <input type="email" class="form-control" value={email} onChange={e=>setEmail(e.target.value)}/>
            <span class="text-danger" id="email"></span>
           </div>
           <div class="form-group">
            <label for="pwd">Password:</label>
            <input type="text" class="form-control" value={password} onChange={e=>setPassword(e.target.value)}/>
             <span class="text-danger" id="password"></span>     
            </div>
 
           <div class="form-group">
           <label for="mobile">Mobile:</label>
           <input type="number" class="form-control"  value={mobile} onChange={e=>setMobile(e.target.value)}/>
           <span class="text-danger" id="mobile"></span>
           </div>
           <div class="form-group">
           <label for="address">Address:</label>
           <textarea rows="5" class="form-control" value={address} onChange={e=>setAddress(e.target.value)}></textarea>
           <span class="text-danger" id="address"></span> 
          </div>
          <div class="form-group">
         <label for="city">City:</label>
        <select  value={city} onChange={e=>setCity(e.target.value)} >
         <option>Select City</option>
         <option>Indore</option>
         <option>Bhopal</option>
         <option >Ujjain</option> 
        </select>
        <span class="text-danger" id="city"></span>
        </div>
      
           <div class="form-group">
           <label for="gender">Gender:</label>
           &nbsp;&nbsp;
           Male<input type="radio" name="gender" value="male" onChange={e=>setGender(e.target.value)}/>
           &nbsp;&nbsp;
           FeMale<input type="radio" name="gender" value="female" onChange={e=>setGender(e.target.value)}/>
           <span class="text-danger" id="gender"></span>
           </div>
        
          <button type="button" onClick={handleForm} class="btn btn-primary" >Submit</button>
        </form>
        </div>
        </div>
       </div>
    </div>
  </section>

  {/* end (about)Home section */}
  </>
);
}
export default Register;
mport {useEffect, useState} from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {

    const Nevigate = useNavigate()

    const[email , setEmail] = useState()
    const[password , setPassword] = useState()

    let user = JSON.parse(localStorage.getItem("user"));
    
     const submit = () => {

        if(email == user.email && password==user.password){
              let obj =JSON.stringify({"name":user.name , "email":email , "password":password , "login":true});
              localStorage.setItem("user",obj);
              Nevigate("/")
        }
       else{
        alert("incorrect email & password")
       }

      } 

              return(
                  <>
                  