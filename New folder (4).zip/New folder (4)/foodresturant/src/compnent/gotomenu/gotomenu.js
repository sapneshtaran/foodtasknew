
import { useState } from 'react';
import './gotomenu.css';

import { sareData } from '../contextapi/context'
import { useContext } from 'react';


function Gotomenu() {
  const { selectproduct, setselectproduct } = useContext(sareData)
  const { quantity, setQuantity } = useContext(sareData);

  const [img, setImg] = useState([
    { id: 1, name: "Burger", Price: 200, imgurl: "/assets/img/burger.jpeg" },
    { id: 2, name: "Coke", Price: 50, imgurl: "/assets/img/coke.jpeg" },
    { id: 3, name: "Fries", Price: 100, imgurl: "/assets/img/fries.jpeg" },
    { id: 3, name: "Pepsi", Price: 50, imgurl: "/assets/img/pepsi.jpeg" },

  ])
  const clickbtu = (id) => {

    let result = img.filter((item) => item.id == id)
    setselectproduct([...selectproduct, result[0]])


  }
 
  const clickbtnremove = (id) => {
    var result = selectproduct.filter((item) => item.id != id)
    setselectproduct(result)
  }



  return (

    <>


      <center>
        {
          img.map((row) => (


            <div class="card" style={{ width: "18rem", height: "auto", display: "inline-block" }}>
              <img src={row.imgurl} class="card-img-top" alt="..." />
              <div class="card-body">
                <label>ProductName :</label>{row.name}<br />
                <label>Price :</label>{row.Price}<br />
             

                <a class=" btu btn-primary" onClick={() => clickbtu(row.id, quantity)}>+</a>

                <a class=" btu btn-primary" onClick={() => clickbtnremove(row.id)}>-</a>


              </div>
            </div>
          ))
        }


      </center>
    </>
  );
}

export default Gotomenu;
