import './register.css';
import { useState } from 'react';
import axios from 'axios';


function Register() {
    const [name, setName] = useState();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const [mobile, setMobile] = useState();
    
    const [output, setOutput] = useState();
    const handleSubmit = () => {
        var obj={"name":name,"email":email,"password":password,"mobile":mobile};
        axios.post("http://127.0.0.1:3001/user/save",obj).then(()=>{
             setOutput("Submited succesfully");
            setName("");
            setEmail("");
            setPassword("");
            setMobile("");
            }).catch((error) => {

                 // name validation
                if(obj.name == undefined || obj.name == ""){
                    alert("Name is required")
                  }


                  const validateEmail = (mail) => {
                    return mail.match(
                      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                    );
                  };
            
                  if(obj.email == undefined || obj.email == ""){
                    alert('This field is required');
                  }
                  else if(validateEmail(obj.email)) {
                   
                  }else{
                    alert('Please enter valid email address.');
                  }
        });
 };
    return (
        <>
            <br /><br />
         

                <center><h1>Register Page</h1></center>
                <div style={{ color: "blue", fontSize: "40px", alignContent: "center", textAlign: "center" }}>
                    {output}
                </div>
                <div class="container ">

                    <div class="shadow p-3 mb-5 bg-body-tertiary rounded">
                        <form class="was-validated" >

                            <div class="row mb-4">
                                <div class="col">
                                    <div class="form-outline">
                                        <label class="form-label" for="form6Example1">Full name</label>
                                        <input type="text" id="name1" class="form-control" name="name" value={name} onChange={e => setName(e.target.value)} />

                                    </div>
                                </div>

                            </div>
                            <div class="form-outline mb-4">
                                <label class="form-label" for="form6Example5">Email</label>
                                <input type="email" id="mail" class="form-control" required name="email" value={email} onChange={e => setEmail(e.target.value)} />

                            </div>
                            <div class="form-outline mb-4">
                                <label class="form-label" for="form6Example4">Password</label>
                                <input type="pass"  class="form-control" name="password" value={password} onChange={e => setPassword(e.target.value)} />

                            </div>


                            <div class="form-outline mb-4">
                                <label class="form-label" for="form6Example6">Mobile</label>
                                <input type="text" id="form6Example6" class="form-control" name="mobile" value={mobile} onChange={e => setMobile(e.target.value)} />

                            </div>

                            <input type="button" class="btn btn-primary btn-block mb-4" value="Submit" onClick={ handleSubmit} />
                        </form>
                    </div>
                </div>
           
        </>

    );
}

export default Register;
