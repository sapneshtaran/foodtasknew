
import './header.css'
import { useContext, useEffect, useState } from 'react';
import { sareData } from '../contextapi/context';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import { Link } from 'react-router-dom';

function Header() {

  let { selectproduct, setselectproduct } = useContext(sareData);

  let len = (selectproduct.length)
  const [Headercontent, setHeadercontent] = useState();
  useEffect(() => {
    //employeepannel navbar to navigate empolyeepannel page
    if (localStorage.getItem("role") == "user") {
      setHeadercontent(
        <>
          <nav class="navbar navbar-expand-lg root">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">{< RestaurantIcon />}Food's Restaurant</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
          
                  <a class="nav-link " aria-current="page" ><Link to="/addtocart">{< AddShoppingCartIcon />}<sup id='sup'>{len}</sup></Link></a>
                  <Link to="/logout"><a class="nav-link " aria-current="page" >Logout</a></Link>
                </div>
              </div>
            </div>
          </nav>
        </>
      )
    }
    else {
      setHeadercontent(
        <>

          <nav class="navbar navbar-expand-lg root">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">{< RestaurantIcon />}Food's Restaurant</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                  <Link to="/"><a class="nav-link " aria-current="page" > Home</a></Link>
                  <Link to="/register"><a class="nav-link " aria-current="page" > Register</a></Link>
                  <Link to="/login"><a class="nav-link " aria-current="page" >Login</a></Link>



                </div>
              </div>
            </div>
          </nav>
        </>
      )
    }
  })

  return (
    <>

      {Headercontent}
    </>
  )
}
export default Header;