import './addtocart.css';
import React from 'react';
import { useContext } from 'react';
import { sareData } from '../contextapi/context';
import { Link } from 'react-router-dom';


function Addtocart(){
     const {selectproduct,setselectproduct}=useContext(sareData)
     const { quantity, handleQuantityChange } = useContext(sareData);
 const clickbtu=(id)=>{
   var result= selectproduct.filter((item)=>item.id!=id)
     setselectproduct(result)
  }
 
    return(<>
    <center>
   
 {
    selectproduct.map((row)=>(
        
 
 <div class="card" style={{width: "18rem",display:"inline-block"}}>
  <img src={row.imgurl} class="card-img-top" alt="..."/>
  <div class="card-body">
  <label>ProductName :</label>{row.name}<br/>
  <label>Price :</label>{row.Price*quantity}<br/>

      <a class=" btu btn-primary" onClick={()=>clickbtu(row.id)}>Remove</a>
      <a class=" btu btn-primary"  >Buy NOw</a>


    

  </div>
</div>


   ))
 }
 </center>


    </>)

}
export default Addtocart;