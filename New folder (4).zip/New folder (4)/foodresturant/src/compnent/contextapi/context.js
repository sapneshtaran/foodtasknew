import { createContext,useState } from "react";
export const sareData=createContext();
export const Hello = ({children})=>{
    const [quantity, setQuantity] = useState(1);


  

    const [selectproduct,setselectproduct]=useState([]);
    return(
        <sareData.Provider value={{selectproduct,setselectproduct,quantity, setQuantity}}>
            {children}
        </sareData.Provider>
    )
}