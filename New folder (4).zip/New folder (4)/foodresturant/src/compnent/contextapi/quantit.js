import React, { createContext, useState } from 'react';

const QuantityContext = createContext();

const QuantityProvider = ({ children }) => {
  const [quantity, setQuantity] = useState(1);

  const handleQuantityChange = (change) => {
    setQuantity(Math.max(quantity + change, 1));
  };

  const value = { quantity, handleQuantityChange };

  return (
    <QuantityContext.Provider value={value}>
      {children}
    </QuantityContext.Provider>
  );
};

export { QuantityContext, QuantityProvider };
