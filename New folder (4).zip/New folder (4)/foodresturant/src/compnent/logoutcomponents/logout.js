import { Navigate } from 'react-router-dom'
import './logout.css'



function Logout(){

    localStorage.removeItem('id')
    localStorage.removeItem('name')
    localStorage.removeItem('lastname')
    localStorage.removeItem('email')
    localStorage.removeItem('mobile')
    localStorage.removeItem('address')
    localStorage.removeItem('city')
    localStorage.removeItem('gender')
    localStorage.removeItem('info')
    localStorage.removeItem('role')
    return(
    <>
    <Navigate to='/Login'/>
</>
)
}
export default Logout;