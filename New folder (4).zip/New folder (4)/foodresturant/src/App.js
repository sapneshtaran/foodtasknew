
import './App.css';
import Home from './compnent/homecomponent/home';
import Header from './compnent/headercomponent/header';
import { Route, Routes } from 'react-router-dom';
import Addtocart from './compnent/Addtocartcomponent/addtocart';
import Main from './compnent/maincomponent/main';
import Register from './compnent/Registercomponent/register';
import Login from './compnent/Logincomponent/login';
import Gotomenu from './compnent/gotomenu/gotomenu';
import Logout from './compnent/logoutcomponents/logout'
function App() {



  return (
    <>
      <Header />

      <Routes>
        <Route path='/main' element={<Main />}></Route>
        <Route path='/' element={<Home />}></Route>
        <Route path='/register' element={<Register />}></Route>
        <Route path='/login' element={<Login />}></Route>
        <Route path='/gotomenu' element={<Gotomenu />}></Route>
        <Route path="/logout" element={<Logout />}></Route>
        <Route path="/addtocart" element={<Addtocart />}></Route>
      </Routes>


    </>
  );
}

export default App;
