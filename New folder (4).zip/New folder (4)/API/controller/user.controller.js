import '../models/connection.js';
import UserSchemaModel from '../models/user.model.js'; 
import jwt from 'jsonwebtoken';
import rs from 'randomstring';
import url from 'url';

export var save=async (req,res,next)=>{
    var userDetails=req.body
    var userList = await UserSchemaModel.find();
    var l=userList.length;
    var _id=l==0?1:userList[l-1]._id+1;
    userDetails={...userDetails,"_id":_id,"status":0,"role":"user","info":Date()};
    try
    {
     var user=await UserSchemaModel.create(userDetails);
     res.status(201).json({"status":true});
    }
    catch(err)
    {
     //console.log(err);
     res.status(500).json({"status": false});
    }
};

export var login=async (req,res,next)=>{
    var userDetails=req.body;
    console.log(userDetails)
    userDetails={...userDetails};
    var userList = await UserSchemaModel.find(userDetails);
    var l=userList.length;
    if(l!=0)
    {
      let payload={"subject":userList[0].email};
      let key=rs.generate();
      let token=jwt.sign(payload,key);
      return res.status(201).json({"token":token,"userDetails":userList[0]});
    }
    else
      return res.status(500).json({"token": "error"});
};

