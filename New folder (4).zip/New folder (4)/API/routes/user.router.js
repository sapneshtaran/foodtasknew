import express from 'express';
const router = express.Router();

//to link controller
import * as UserController from '../controller/user.controller.js'; 

router.post("/save",UserController.save);

router.post("/login",UserController.login);

export default router;